# Uge36: Intro

https://cphbusiness.zoom.us/j/6402861505?pwd=YWhYWVlVT3BjbFdBVzZ3bHpPMHZ5UT09

https://join.slack.com/t/e2020dat1/shared_invite/zt-gzy8chxu-jZ4UJ0GKrRT13_0kyF_56A


Passcode: F2020Dat1
